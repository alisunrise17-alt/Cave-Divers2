export interface Client {
  id: string;
  fullName: string;
  dateOfBirth: string;
  email: string;
  licenseLevel: LicenseLevel;
  profilePicture: string | null;
  notes: string;
  createdAt: string;
}

export type LicenseLevel = 
  | 'Open Water Diver'
  | 'Advanced Open Water'
  | 'Rescue Diver'
  | 'Divemaster'
  | 'Instructor';

export interface User {
  email: string;
  isAuthenticated: boolean;
}

export interface BirthdayAlert {
  client: Client;
  daysUntil: number;
  isToday: boolean;
}