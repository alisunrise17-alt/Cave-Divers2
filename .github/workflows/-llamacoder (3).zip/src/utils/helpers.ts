import { Client, BirthdayAlert } from '../types';

export const formatDateDisplay = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
};

export const getDaysUntilBirthday = (dateOfBirth: string): number => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const birthDate = new Date(dateOfBirth);
  const nextBirthday = new Date(
    today.getFullYear(),
    birthDate.getMonth(),
    birthDate.getDate()
  );
  
  if (nextBirthday < today) {
    nextBirthday.setFullYear(today.getFullYear() + 1);
  }
  
  const diffTime = nextBirthday.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays;
};

export const getBirthdayAlerts = (clients: Client[]): BirthdayAlert[] => {
  return clients
    .map(client => ({
      client,
      daysUntil: getDaysUntilBirthday(client.dateOfBirth),
      isToday: getDaysUntilBirthday(client.dateOfBirth) === 0
    }))
    .filter(alert => alert.daysUntil <= 30)
    .sort((a, b) => a.daysUntil - b.daysUntil);
};

export const getAge = (dateOfBirth: string): number => {
  const today = new Date();
  const birthDate = new Date(dateOfBirth);
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  
  return age;
};

export const licenseColors: Record<string, string> = {
  'Open Water Diver': 'bg-blue-100 text-blue-800',
  'Advanced Open Water': 'bg-teal-100 text-teal-800',
  'Rescue Diver': 'bg-amber-100 text-amber-800',
  'Divemaster': 'bg-purple-100 text-purple-800',
  'Instructor': 'bg-rose-100 text-rose-800'
};