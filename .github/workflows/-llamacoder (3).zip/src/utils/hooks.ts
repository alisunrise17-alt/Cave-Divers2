import { useState } from 'react';
import { Client, User } from '../types';

const CLIENTS_KEY = 'cave_divers_clients';
const USER_KEY = 'cave_divers_user';

export const useLocalStorage = <T>(key: string, initialValue: T): [T, (value: T) => void] => {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });

  const setValue = (value: T) => {
    try {
      setStoredValue(value);
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
  };

  return [storedValue, setValue];
};

export const useClients = () => {
  const [clients, setClients] = useLocalStorage<Client[]>(CLIENTS_KEY, []);

  const addClient = (client: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = {
      ...client,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setClients([...clients, newClient]);
    return newClient;
  };

  const updateClient = (id: string, updates: Partial<Client>) => {
    setClients(clients.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const deleteClient = (id: string) => {
    setClients(clients.filter(c => c.id !== id));
  };

  return { clients, addClient, updateClient, deleteClient };
};

export const useAuth = () => {
  const [user, setUser] = useLocalStorage<User | null>(USER_KEY, null);

  const login = (email: string, password: string): boolean => {
    if (email === 'ali.sunrise17@gmail.com' && password === 'Admin123') {
      setUser({ email, isAuthenticated: true });
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  return { user, login, logout };
};