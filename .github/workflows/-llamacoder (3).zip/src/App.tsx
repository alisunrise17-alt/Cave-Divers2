import { useState, useEffect } from 'react';
import { LoginForm } from './components/LoginForm';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { ClientList } from './components/ClientList';
import { BirthdayReminders } from './components/BirthdayReminders';
import { Settings } from './components/Settings';
import { useAuth, useClients } from './utils/hooks';

export default function App() {
  const { user, login, logout } = useAuth();
  const { clients, addClient, updateClient, deleteClient } = useClients();
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [darkMode, setDarkMode] = useState(true);

  useEffect(() => {
    document.body.className = darkMode ? 'bg-slate-900' : 'bg-slate-100';
  }, [darkMode]);

  if (!user?.isAuthenticated) {
    return <LoginForm onLogin={login} />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard clients={clients} onNavigate={setCurrentPage} darkMode={darkMode} />;
      case 'clients':
        return (
          <ClientList
            clients={clients}
            onAdd={addClient}
            onUpdate={updateClient}
            onDelete={deleteClient}
            darkMode={darkMode}
          />
        );
      case 'birthdays':
        return <BirthdayReminders clients={clients} darkMode={darkMode} />;
      case 'settings':
        return <Settings darkMode={darkMode} onToggleDarkMode={() => setDarkMode(!darkMode)} />;
      default:
        return <Dashboard clients={clients} onNavigate={setCurrentPage} darkMode={darkMode} />;
    }
  };

  return (
    <div className={`flex min-h-screen ${darkMode ? 'bg-slate-900' : 'bg-slate-50'}`}>
      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onLogout={logout}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
      />
      <main className="flex-1 overflow-auto">
        {renderPage()}
      </main>
    </div>
  );
}