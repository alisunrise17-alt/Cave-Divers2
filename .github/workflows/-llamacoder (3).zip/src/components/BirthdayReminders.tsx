import { Client } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Calendar, Mail, Star } from 'lucide-react';
import { getBirthdayAlerts, getAge } from '../utils/helpers';

interface BirthdayRemindersProps {
  clients: Client[];
  darkMode: boolean;
}

export const BirthdayReminders = ({ clients, darkMode }: BirthdayRemindersProps) => {
  const birthdayAlerts = getBirthdayAlerts(clients);
  const todayBirthdays = birthdayAlerts.filter(a => a.isToday);
  const upcomingBirthdays = birthdayAlerts.filter(a => !a.isToday && a.daysUntil <= 7);
  const laterBirthdays = birthdayAlerts.filter(a => a.daysUntil > 7);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>Birthday Reminders</h1>
        <p className={`mt-1 ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>Track and celebrate client birthdays</p>
      </div>

      {todayBirthdays.length > 0 && (
        <Card className="bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Star className="w-5 h-5" />
              Today's Birthdays! 🎉
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {todayBirthdays.map((alert) => (
              <div key={alert.client.id} className="flex items-center gap-4 bg-white/20 rounded-xl p-4">
                {alert.client.profilePicture ? (
                  <img src={alert.client.profilePicture} alt={alert.client.fullName} className="w-14 h-14 rounded-full object-cover ring-2 ring-white/50" />
                ) : (
                  <div className="w-14 h-14 rounded-full bg-white/30 flex items-center justify-center text-white text-xl font-bold ring-2 ring-white/50">
                    {alert.client.fullName.charAt(0)}
                  </div>
                )}
                <div className="flex-1">
                  <p className="font-semibold text-lg">{alert.client.fullName}</p>
                  <p className="text-white/80">Turning {getAge(alert.client.dateOfBirth) + 1} today!</p>
                </div>
                <a href={`mailto:${alert.client.email}`} className="flex items-center gap-2 px-4 py-2 bg-white/20 rounded-lg hover:bg-white/30 transition-colors">
                  <Mail className="w-4 h-4" />
                  Send Wishes
                </a>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm`}>
          <CardHeader className={`${darkMode ? 'border-slate-700' : 'border-slate-200'} border-b`}>
            <CardTitle className={`flex items-center gap-2 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
              <Calendar className="w-5 h-5 text-purple-500" />
              Upcoming (Next 7 Days)
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {upcomingBirthdays.length === 0 ? (
              <p className={`text-center py-8 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>No birthdays in the next 7 days</p>
            ) : (
              <div className="space-y-3">
                {upcomingBirthdays.map((alert) => (
                  <div key={alert.client.id} className={`flex items-center gap-3 p-3 rounded-xl ${darkMode ? 'bg-slate-700/50' : 'bg-slate-50'}`}>
                    {alert.client.profilePicture ? (
                      <img src={alert.client.profilePicture} alt={alert.client.fullName} className="w-10 h-10 rounded-full object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-white font-semibold">
                        {alert.client.fullName.charAt(0)}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className={`font-medium truncate ${darkMode ? 'text-white' : 'text-slate-800'}`}>{alert.client.fullName}</p>
                      <p className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>In {alert.daysUntil} days</p>
                    </div>
                    <span className={`text-sm font-medium ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>{getAge(alert.client.dateOfBirth)} years</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm`}>
          <CardHeader className={`${darkMode ? 'border-slate-700' : 'border-slate-200'} border-b`}>
            <CardTitle className={`flex items-center gap-2 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
              <Calendar className="w-5 h-5 text-teal-500" />
              Later This Month
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {laterBirthdays.length === 0 ? (
              <p className={`text-center py-8 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>No more birthdays this month</p>
            ) : (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {laterBirthdays.map((alert) => (
                  <div key={alert.client.id} className={`flex items-center gap-3 p-3 rounded-xl ${darkMode ? 'bg-slate-700/50' : 'bg-slate-50'}`}>
                    {alert.client.profilePicture ? (
                      <img src={alert.client.profilePicture} alt={alert.client.fullName} className="w-10 h-10 rounded-full object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center text-white font-semibold">
                        {alert.client.fullName.charAt(0)}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className={`font-medium truncate ${darkMode ? 'text-white' : 'text-slate-800'}`}>{alert.client.fullName}</p>
                      <p className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>In {alert.daysUntil} days</p>
                    </div>
                    <span className={`text-sm font-medium ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>{getAge(alert.client.dateOfBirth)} years</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};