import { Client } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Users, Calendar, Clock, Star } from 'lucide-react';
import { getBirthdayAlerts, getAge, licenseColors } from '../utils/helpers';

interface DashboardProps {
  clients: Client[];
  onNavigate: (page: string) => void;
  darkMode: boolean;
}

export const Dashboard = ({ clients, onNavigate, darkMode }: DashboardProps) => {
  const birthdayAlerts = getBirthdayAlerts(clients);
  const todayBirthdays = birthdayAlerts.filter(a => a.isToday);
  const upcomingBirthdays = birthdayAlerts.filter(a => !a.isToday && a.daysUntil <= 7);
  const recentClients = [...clients]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const stats = [
    { label: 'Total Clients', value: clients.length, icon: Users, color: 'from-cyan-500 to-blue-600' },
    { label: "Today's Birthdays", value: todayBirthdays.length, icon: Star, color: 'from-amber-500 to-orange-600' },
    { label: 'Upcoming (7 days)', value: upcomingBirthdays.length, icon: Calendar, color: 'from-purple-500 to-pink-600' },
    { label: 'Instructors', value: clients.filter(c => c.licenseLevel === 'Instructor').length, icon: Star, color: 'from-teal-500 to-emerald-600' },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>Dashboard</h1>
          <p className={`mt-1 ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>Welcome back! Here's your diving center overview.</p>
        </div>
        <div className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
          {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm hover:shadow-lg transition-shadow`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>{stat.label}</p>
                    <p className={`text-3xl font-bold mt-1 ${darkMode ? 'text-white' : 'text-slate-800'}`}>{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm`}>
          <CardHeader className={`${darkMode ? 'border-slate-700' : 'border-slate-200'} border-b`}>
            <CardTitle className={`flex items-center gap-2 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
              <Calendar className="w-5 h-5 text-cyan-500" />
              Birthday Reminders
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {birthdayAlerts.length === 0 ? (
              <p className={`text-center py-8 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>No upcoming birthdays in the next 30 days</p>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {birthdayAlerts.slice(0, 8).map((alert) => (
                  <div key={alert.client.id} className={`flex items-center gap-3 p-3 rounded-xl ${
                    alert.isToday 
                      ? 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30' 
                      : darkMode ? 'bg-slate-700/50' : 'bg-slate-50'
                  }`}>
                    {alert.client.profilePicture ? (
                      <img src={alert.client.profilePicture} alt={alert.client.fullName} className="w-10 h-10 rounded-full object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white font-semibold">
                        {alert.client.fullName.charAt(0)}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className={`font-medium truncate ${darkMode ? 'text-white' : 'text-slate-800'}`}>{alert.client.fullName}</p>
                      <p className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                        {alert.isToday ? '🎉 Birthday Today!' : `In ${alert.daysUntil} days`}
                      </p>
                    </div>
                    <span className={`text-sm font-medium ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>{getAge(alert.client.dateOfBirth)} years</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm`}>
          <CardHeader className={`${darkMode ? 'border-slate-700' : 'border-slate-200'} border-b`}>
            <CardTitle className={`flex items-center gap-2 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
              <Clock className="w-5 h-5 text-cyan-500" />
              Recently Added Clients
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {recentClients.length === 0 ? (
              <p className={`text-center py-8 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>No clients added yet</p>
            ) : (
              <div className="space-y-3">
                {recentClients.map((client) => (
                  <div key={client.id} className={`flex items-center gap-3 p-3 rounded-xl ${darkMode ? 'bg-slate-700/50' : 'bg-slate-50'}`}>
                    {client.profilePicture ? (
                      <img src={client.profilePicture} alt={client.fullName} className="w-10 h-10 rounded-full object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white font-semibold">
                        {client.fullName.charAt(0)}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className={`font-medium truncate ${darkMode ? 'text-white' : 'text-slate-800'}`}>{client.fullName}</p>
                      <p className={`text-sm truncate ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>{client.email}</p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${licenseColors[client.licenseLevel]}`}>
                      {client.licenseLevel.split(' ')[0]}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-4">
        <button onClick={() => onNavigate('clients')} className="flex-1 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-xl font-semibold hover:from-cyan-600 hover:to-blue-700 transition-all shadow-lg shadow-cyan-500/25">
          Manage Clients
        </button>
        <button onClick={() => onNavigate('birthdays')} className="flex-1 py-4 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl font-semibold hover:from-purple-600 hover:to-pink-700 transition-all shadow-lg shadow-purple-500/25">
          View All Birthdays
        </button>
      </div>
    </div>
  );
};