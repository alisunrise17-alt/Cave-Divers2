import { Home, Users, Calendar, Settings, LogOut, Waves, Moon, Sun } from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onLogout: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export const Sidebar = ({ 
  currentPage, 
  onNavigate, 
  onLogout, 
  darkMode,
  onToggleDarkMode 
}: SidebarProps) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'clients', label: 'Clients', icon: Users },
    { id: 'birthdays', label: 'Birthdays', icon: Calendar },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className={`w-64 min-h-screen ${darkMode ? 'bg-slate-800' : 'bg-white'} border-r ${darkMode ? 'border-slate-700' : 'border-slate-200'} flex flex-col`}>
      <div className={`p-6 border-b ${darkMode ? 'border-slate-700' : 'border-slate-200'}`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
            <Waves className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className={`font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>Cave Divers</h1>
            <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Management System</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <li key={item.id}>
                <button
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                      : darkMode
                        ? 'text-slate-400 hover:bg-slate-700 hover:text-white'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className={`p-4 border-t ${darkMode ? 'border-slate-700' : 'border-slate-200'}`}>
        <button
          onClick={onToggleDarkMode}
          className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl mb-2 transition-all ${
            darkMode 
              ? 'text-slate-400 hover:bg-slate-700 hover:text-white' 
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800'
          }`}
        >
          {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          <span className="font-medium">{darkMode ? 'Light Mode' : 'Dark Mode'}</span>
        </button>
        
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-all"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Logout</span>
        </button>
      </div>
    </aside>
  );
};