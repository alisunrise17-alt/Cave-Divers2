import { useState } from 'react';
import { Client, LicenseLevel } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Plus, Search, Edit, Trash2, Mail, X, Upload, Users, Filter } from 'lucide-react';
import { licenseColors, formatDateDisplay, getAge } from '../utils/helpers';

interface ClientListProps {
  clients: Client[];
  onAdd: (client: Omit<Client, 'id' | 'createdAt'>) => void;
  onUpdate: (id: string, updates: Partial<Client>) => void;
  onDelete: (id: string) => void;
  darkMode: boolean;
}

const licenseLevels: LicenseLevel[] = ['Open Water Diver', 'Advanced Open Water', 'Rescue Diver', 'Divemaster', 'Instructor'];

export const ClientList = ({ clients, onAdd, onUpdate, onDelete, darkMode }: ClientListProps) => {
  const [search, setSearch] = useState('');
  const [filterLevel, setFilterLevel] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [formData, setFormData] = useState({
    fullName: '',
    dateOfBirth: '',
    email: '',
    licenseLevel: 'Open Water Diver' as LicenseLevel,
    profilePicture: null as string | null,
    notes: ''
  });

  const filteredClients = clients.filter(client => {
    const matchesSearch = client.fullName.toLowerCase().includes(search.toLowerCase()) || client.email.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filterLevel === 'all' || client.licenseLevel === filterLevel;
    return matchesSearch && matchesFilter;
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.addEventListener('load', () => setFormData({ ...formData, profilePicture: reader.result as string }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingClient) onUpdate(editingClient.id, formData);
    else onAdd(formData);
    closeModal();
  };

  const openEditModal = (client: Client) => {
    setEditingClient(client);
    setFormData({
      fullName: client.fullName,
      dateOfBirth: client.dateOfBirth,
      email: client.email,
      licenseLevel: client.licenseLevel,
      profilePicture: client.profilePicture,
      notes: client.notes
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingClient(null);
    setFormData({ fullName: '', dateOfBirth: '', email: '', licenseLevel: 'Open Water Diver', profilePicture: null, notes: '' });
  };

  const exportToCSV = () => {
    const headers = ['Name', 'Email', 'Date of Birth', 'License Level', 'Notes'];
    const rows = clients.map(c => [c.fullName, c.email, c.dateOfBirth, c.licenseLevel, c.notes]);
    const csvContent = [headers.join(','), ...rows.map(row => row.map(cell => `"${cell}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cave-divers-clients.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>Client Management</h1>
          <p className={`mt-1 ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>Manage your diving center clients</p>
        </div>
        <div className="flex gap-3">
          <Button onClick={exportToCSV} variant="outline" className={darkMode ? 'border-slate-600 text-slate-300 hover:bg-slate-700' : 'border-slate-300 text-slate-600 hover:bg-slate-100'}>Export CSV</Button>
          <Button onClick={() => setShowModal(true)} className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white shadow-lg shadow-cyan-500/25">
            <Plus className="w-4 h-4 mr-2" />Add Client
          </Button>
        </div>
      </div>

      <Card className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm`}>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`} />
              <Input placeholder="Search by name or email..." value={search} onChange={(e) => setSearch(e.target.value)} className={`pl-10 ${darkMode ? 'bg-slate-700 border-slate-600 text-white placeholder:text-slate-400' : 'bg-slate-50 border-slate-200'}`} />
            </div>
            <div className="flex items-center gap-2">
              <Filter className={`w-5 h-5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`} />
              <Select value={filterLevel} onValueChange={setFilterLevel}>
                <SelectTrigger className={`w-48 ${darkMode ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200'}`}>
                  <SelectValue placeholder="Filter by level" />
                </SelectTrigger>
                <SelectContent className={darkMode ? 'bg-slate-700 border-slate-600' : 'bg-white'}>
                  <SelectItem value="all">All Levels</SelectItem>
                  {licenseLevels.map(level => <SelectItem key={level} value={level}>{level}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredClients.length === 0 ? (
          <div className="col-span-full">
            <Card className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm`}>
              <CardContent className="p-12 text-center">
                <Users className={`w-16 h-16 mx-auto mb-4 ${darkMode ? 'text-slate-600' : 'text-slate-300'}`} />
                <p className={`text-lg ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  {search || filterLevel !== 'all' ? 'No clients match your search criteria' : 'No clients added yet. Click "Add Client" to get started.'}
                </p>
              </CardContent>
            </Card>
          </div>
        ) : (
          filteredClients.map((client) => (
            <Card key={client.id} className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm hover:shadow-lg transition-all`}>
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  {client.profilePicture ? (
                    <img src={client.profilePicture} alt={client.fullName} className="w-14 h-14 rounded-full object-cover ring-2 ring-cyan-500/20" />
                  ) : (
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white text-xl font-bold ring-2 ring-cyan-500/20">
                      {client.fullName.charAt(0)}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <h3 className={`font-semibold truncate ${darkMode ? 'text-white' : 'text-slate-800'}`}>{client.fullName}</h3>
                    <a href={`mailto:${client.email}`} className={`flex items-center gap-1 text-sm ${darkMode ? 'text-cyan-400 hover:text-cyan-300' : 'text-cyan-600 hover:text-cyan-700'} transition-colors`}>
                      <Mail className="w-3.5 h-3.5" /><span className="truncate">{client.email}</span>
                    </a>
                  </div>
                </div>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>License</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${licenseColors[client.licenseLevel]}`}>{client.licenseLevel}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Age</span>
                    <span className={`text-sm font-medium ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>{getAge(client.dateOfBirth)} years</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Birthday</span>
                    <span className={`text-sm ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>{formatDateDisplay(client.dateOfBirth)}</span>
                  </div>
                </div>
                {client.notes && <p className={`mt-3 text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'} line-clamp-2`}>{client.notes}</p>}
                <div className={`flex gap-2 mt-4 pt-4 border-t ${darkMode ? 'border-slate-700' : 'border-slate-200'}`}>
                  <Button onClick={() => openEditModal(client)} variant="outline" size="sm" className={`flex-1 ${darkMode ? 'border-slate-600 text-slate-300 hover:bg-slate-700' : 'border-slate-200 text-slate-600 hover:bg-slate-100'}`}>
                    <Edit className="w-4 h-4 mr-1" />Edit
                  </Button>
                  <Button onClick={() => { if (confirm('Are you sure you want to delete this client?')) onDelete(client.id); }} variant="outline" size="sm" className="text-red-500 border-red-200 hover:bg-red-50">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <Card className={`w-full max-w-lg max-h-[90vh] overflow-y-auto ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white'} shadow-2xl`}>
            <CardHeader className={`${darkMode ? 'border-slate-700' : 'border-slate-200'} border-b`}>
              <div className="flex items-center justify-between">
                <CardTitle className={darkMode ? 'text-white' : 'text-slate-800'}>{editingClient ? 'Edit Client' : 'Add New Client'}</CardTitle>
                <button onClick={closeModal} className={darkMode ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-700'}><X className="w-5 h-5" /></button>
              </div>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName" className={darkMode ? 'text-slate-300' : ''}>Full Name *</Label>
                  <Input id="fullName" value={formData.fullName} onChange={(e) => setFormData({ ...formData, fullName: e.target.value })} required className={darkMode ? 'bg-slate-700 border-slate-600 text-white' : ''} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className={darkMode ? 'text-slate-300' : ''}>Email Address *</Label>
                  <Input id="email" type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} required className={darkMode ? 'bg-slate-700 border-slate-600 text-white' : ''} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth" className={darkMode ? 'text-slate-300' : ''}>Date of Birth *</Label>
                  <Input id="dateOfBirth" type="date" value={formData.dateOfBirth} onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })} required className={darkMode ? 'bg-slate-700 border-slate-600 text-white' : ''} />
                </div>
                <div className="space-y-2">
                  <Label className={darkMode ? 'text-slate-300' : ''}>Diving License Level *</Label>
                  <Select value={formData.licenseLevel} onValueChange={(value) => setFormData({ ...formData, licenseLevel: value as LicenseLevel })}>
                    <SelectTrigger className={darkMode ? 'bg-slate-700 border-slate-600 text-white' : ''}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className={darkMode ? 'bg-slate-700 border-slate-600' : 'bg-white'}>
                      {licenseLevels.map(level => <SelectItem key={level} value={level}>{level}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className={darkMode ? 'text-slate-300' : ''}>Profile Picture</Label>
                  <div className="flex items-center gap-4">
                    {formData.profilePicture && <img src={formData.profilePicture} alt="Preview" className="w-16 h-16 rounded-full object-cover" />}
                    <label className={`flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer ${darkMode ? 'bg-slate-700 text-slate-300 hover:bg-slate-600' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                      <Upload className="w-4 h-4" />
                      <span>Upload Image</span>
                      <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                    </label>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes" className={darkMode ? 'text-slate-300' : ''}>Notes</Label>
                  <Textarea id="notes" value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} rows={3} className={darkMode ? 'bg-slate-700 border-slate-600 text-white' : ''} />
                </div>
              </CardContent>
              <div className={`flex gap-3 p-6 border-t ${darkMode ? 'border-slate-700' : 'border-slate-200'}`}>
                <Button type="button" onClick={closeModal} variant="outline" className={`flex-1 ${darkMode ? 'border-slate-600 text-slate-300 hover:bg-slate-700' : 'border-slate-200 text-slate-600 hover:bg-slate-100'}`}>Cancel</Button>
                <Button type="submit" className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white">{editingClient ? 'Update Client' : 'Add Client'}</Button>
              </div>
            </form>
          </Card>
        </div>
      )}
    </div>
  );
};