import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Sun, Moon, Shield, Database } from 'lucide-react';

interface SettingsProps {
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export const Settings = ({ darkMode, onToggleDarkMode }: SettingsProps) => {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>Settings</h1>
        <p className={`mt-1 ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>Configure your application preferences</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm`}>
          <CardHeader className={`${darkMode ? 'border-slate-700' : 'border-slate-200'} border-b`}>
            <CardTitle className={`flex items-center gap-2 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
              {darkMode ? <Moon className="w-5 h-5 text-cyan-400" /> : <Sun className="w-5 h-5 text-amber-500" />}
              Appearance
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className={`font-medium ${darkMode ? 'text-white' : 'text-slate-800'}`}>Dark Mode</p>
                <p className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Toggle between light and dark theme</p>
              </div>
              <button
                onClick={onToggleDarkMode}
                className={`relative w-14 h-8 rounded-full transition-colors ${darkMode ? 'bg-cyan-500' : 'bg-slate-300'}`}
              >
                <span className={`absolute top-1 w-6 h-6 rounded-full bg-white shadow transition-transform ${darkMode ? 'right-1' : 'left-1'}`} />
              </button>
            </div>
          </CardContent>
        </Card>

        <Card className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm`}>
          <CardHeader className={`${darkMode ? 'border-slate-700' : 'border-slate-200'} border-b`}>
            <CardTitle className={`flex items-center gap-2 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
              <Database className="w-5 h-5 text-teal-500" />
              Data Management
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className={`p-4 rounded-lg ${darkMode ? 'bg-slate-700' : 'bg-slate-100'}`}>
              <p className={`text-sm ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                All client data is stored locally in your browser's localStorage. Clearing your browser data will remove all stored information.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border shadow-sm`}>
          <CardHeader className={`${darkMode ? 'border-slate-700' : 'border-slate-200'} border-b`}>
            <CardTitle className={`flex items-center gap-2 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
              <Shield className="w-5 h-5 text-purple-500" />
              Security
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className={`p-4 rounded-lg ${darkMode ? 'bg-slate-700' : 'bg-slate-100'}`}>
              <p className={`text-sm ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                Your session is secured with local authentication. Remember to log out when using shared computers.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};